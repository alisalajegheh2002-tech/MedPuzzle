import random
from datetime import datetime

from kivy.app import App
from kivy.clock import Clock
from kivy.core.window import Window
from kivy.metrics import dp
from kivy.graphics import Color, RoundedRectangle, Line
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.label import Label
from kivy.uix.button import Button
from kivy.uix.textinput import TextInput
from kivy.uix.scrollview import ScrollView
from kivy.uix.screenmanager import ScreenManager, Screen
from kivy.uix.popup import Popup
from utils.persian_text import rtl, FONT_PATH

from database.db import (
    initialize_database,
    add_medicine,
    get_all_medicines,
    delete_medicine,
    update_medicine,
    add_medicine_schedule,
    get_medicine_schedules,
    delete_medicine_schedule,
    add_intake_log,
    mark_puzzle_solved,
    mark_medicine_taken,
    get_all_intake_logs,
    intake_log_exists,
)


NAVY = (0.09, 0.15, 0.32, 1)
BLUE = (0.22, 0.47, 0.96, 1)
PURPLE = (0.53, 0.36, 0.92, 1)
BG = (0.95, 0.96, 0.99, 1)
WHITE = (1, 1, 1, 1)
GRAY = (0.40, 0.45, 0.55, 1)
RED = (0.85, 0.20, 0.25, 1)
GREEN = (0.12, 0.60, 0.38, 1)


class Card(BoxLayout):
    def __init__(self, bg_color=WHITE, **kwargs):
        super().__init__(**kwargs)
        self.padding = dp(14)
        self.spacing = dp(8)

        with self.canvas.before:
            Color(*bg_color)
            self.rect = RoundedRectangle(
                pos=self.pos,
                size=self.size,
                radius=[dp(18)]
            )

        self.bind(pos=self.update_rect, size=self.update_rect)

    def update_rect(self, *args):
        self.rect.pos = self.pos
        self.rect.size = self.size


class NavButton(Button):
    """دکمه منوی پایین با آیکون‌های ترسیم‌شده."""

    def __init__(self, icon_type, **kwargs):
        self.icon_type = icon_type
        super().__init__(**kwargs)

        self.halign = "center"
        self.valign = "bottom"

        self.bind(pos=self.draw_icon, size=self.draw_icon)
        self.draw_icon()

    def draw_icon(self, *args):
        self.canvas.after.clear()

        x_center = self.center_x
        y_center = self.y + self.height * 0.70
        r = dp(8)

        color = BLUE if self.state == "down" else self.color

        with self.canvas.after:
            Color(*color)

            if self.icon_type == "home":
                Line(
                    points=[
                        x_center - r, y_center,
                        x_center, y_center + r,
                        x_center + r, y_center
                    ],
                    width=1.7
                )

                Line(
                    rectangle=(
                        x_center - r * 0.72,
                        y_center - r,
                        r * 1.44,
                        r * 1.25
                    ),
                    width=1.7
                )

                Line(
                    points=[
                        x_center, y_center - r,
                        x_center, y_center - r * 0.25
                    ],
                    width=1.7
                )

            elif self.icon_type == "medicine":
                Line(
                    points=[
                        x_center - r * 1.2, y_center - r * 0.55,
                        x_center + r * 1.2, y_center - r * 0.55,
                        x_center + r * 1.2, y_center + r * 0.55,
                        x_center - r * 1.2, y_center + r * 0.55
                    ],
                    close=True,
                    width=1.8
                )

                Line(
                    points=[
                        x_center, y_center - r * 0.5,
                        x_center, y_center + r * 0.5
                    ],
                    width=1.5
                )

            elif self.icon_type == "history":
                Line(
                    circle=(x_center, y_center, r),
                    width=1.8
                )

                Line(
                    points=[
                        x_center, y_center,
                        x_center, y_center + r * 0.55,
                        x_center + r * 0.5, y_center
                    ],
                    width=1.8
                )

            elif self.icon_type == "settings":
                Line(
                    circle=(x_center, y_center, r * 0.72),
                    width=1.8
                )

                Line(
                    circle=(x_center, y_center, r * 0.25),
                    width=1.5
                )

                for angle_x, angle_y in (
                    (0, 1), (0, -1), (1, 0), (-1, 0),
                    (0.7, 0.7), (-0.7, 0.7),
                    (0.7, -0.7), (-0.7, -0.7)
                ):
                    Line(
                        points=[
                            x_center + angle_x * r * 0.82,
                            y_center + angle_y * r * 0.82,
                            x_center + angle_x * r * 1.15,
                            y_center + angle_y * r * 1.15
                        ],
                        width=2
                    )


class MedPuzzleApp(App):

    def build(self):
        self.title = "MedPuzzle"

        Window.size = (390, 800)
        Window.minimum_width = 320
        Window.minimum_height = 500
        Window.clearcolor = BG

        self.editing_medicine_id = None
        self.selected_medicine_id = None
        self.current_intake_log_id = None
        self.correct_answer = None
        self.medicines = []
        self.last_reminder_minute = None
        initialize_database()

        self.manager = ScreenManager()

        self.dashboard = Screen(name="dashboard")
        self.add_screen = Screen(name="add_medicine")
        self.schedule_screen = Screen(name="schedule")
        self.puzzle_screen = Screen(name="puzzle")
        self.history_screen = Screen(name="history")
        self.settings_screen = Screen(name="settings")

        for screen in (
            self.dashboard,
            self.add_screen,
            self.schedule_screen,
            self.puzzle_screen,
            self.history_screen,
            self.settings_screen,
        ):
            self.manager.add_widget(screen)

        self.build_dashboard()
        self.build_add_form()
        self.build_schedule_form()
        self.build_puzzle_screen()
        self.build_history_screen()
        self.build_settings_screen()

        self.main_layout = BoxLayout(
            orientation="vertical",
            spacing=0
        )

        self.main_layout.add_widget(self.manager)

        self.build_bottom_nav()

        self.manager.bind(current=self.update_bottom_nav)

        self.update_bottom_nav(
        self.manager,
        self.manager.current
        )

        # بررسی زمان مصرف داروها هر ۱۵ ثانیه
        Clock.schedule_interval(
            self.check_medicine_reminders,
            15
        )

        return self.main_layout

    # ابزارهای رابط کاربری

    def make_label(
        self, text, size=15, color=NAVY,
        height=dp(35), align="right"
    ):
        label = Label(
            text=rtl(text),
            font_name=str(FONT_PATH),
            font_size=dp(size),
            color=color,
            size_hint_y=None,
            height=height,
            halign=align,
            valign="middle"
        )

        label.bind(
            size=lambda obj, value: setattr(
                obj,
                "text_size",
                (max(0, value[0] - dp(4)), value[1])
            )
        )

        return label

    def make_button(
        self, text, callback, color=BLUE, height=dp(48)
    ):
        button = Button(
            text=rtl(text),
            font_name=str(FONT_PATH),
            font_size=dp(14),
            size_hint_y=None,
            height=height,
            background_normal="",
            background_color=color,
            color=WHITE
        )

        button.bind(on_release=callback)

        return button

    def make_input(
        self, hint, height=dp(48), multiline=False
    ):
        return TextInput(
            hint_text=rtl(hint),
            font_name=str(FONT_PATH),
            font_size=dp(14),
            size_hint_y=None,
            height=height,
            multiline=multiline,
            halign="right",
            padding=[dp(12), dp(12)],
            background_color=WHITE,
            foreground_color=NAVY,
            cursor_color=BLUE
        )

    def make_scroll_page(self, screen):
        root = BoxLayout(
            orientation="vertical",
            padding=dp(14),
            spacing=dp(10)
        )

        scroll = ScrollView(do_scroll_x=False)

        content = BoxLayout(
            orientation="vertical",
            spacing=dp(12),
            size_hint_y=None
        )

        content.bind(
            minimum_height=content.setter("height")
        )

        scroll.add_widget(content)
        root.add_widget(scroll)
        screen.add_widget(root)

        return root, content

    # منوی پایین

    def build_bottom_nav(self):
        self.bottom_nav = BoxLayout(
            orientation="horizontal",
            size_hint_y=None,
            height=dp(68),
            padding=[dp(5), dp(5)],
            spacing=dp(3)
        )

        with self.bottom_nav.canvas.before:
            Color(*WHITE)

            self.bottom_nav_rect = RoundedRectangle(
                pos=self.bottom_nav.pos,
                size=self.bottom_nav.size,
                radius=[dp(15), dp(15), 0, 0]
            )

        self.bottom_nav.bind(
            pos=lambda obj, value: setattr(
                self.bottom_nav_rect, "pos", value
            ),
            size=lambda obj, value: setattr(
                self.bottom_nav_rect, "size", value
            )
        )

        self.nav_buttons = {}

        nav_items = [
            ("dashboard", "home", "خانه"),
            ("medicines", "medicine", "داروها"),
            ("history", "history", "تاریخچه"),
            ("settings", "settings", "تنظیمات"),
        ]

        for page, icon_type, title in reversed(nav_items):
            button = NavButton(
                icon_type=icon_type,
                text=rtl(title),
                font_name=str(FONT_PATH),
                font_size=dp(11),
                text_size=(None, dp(28)),
                background_normal="",
                background_color=(0, 0, 0, 0),
                color=GRAY
            )

            button.bind(
                on_release=lambda instance, target=page:
                    self.navigate_bottom(target)
            )

            self.bottom_nav.add_widget(button)
            self.nav_buttons[page] = button

        self.main_layout.add_widget(self.bottom_nav)

    def navigate_bottom(self, page):
        if page == "dashboard":
            self.manager.current = "dashboard"

        elif page == "medicines":
            self.refresh_medicines()
            self.manager.current = "dashboard"

        elif page == "history":
            self.open_history()

        elif page == "settings":
            self.manager.current = "settings"

    def update_bottom_nav(self, instance, current):
        active_page = current

        if current in ("add_medicine", "schedule"):
            active_page = "medicines"

        for page, button in self.nav_buttons.items():
            button.color = (
                BLUE if page == active_page else GRAY
            )

            button.draw_icon()

    # داشبورد

    def build_dashboard(self):
        root, content = self.make_scroll_page(self.dashboard)

        content.add_widget(
            self.make_label(
                "سلام، روزت بخیر 👋",
                18, NAVY, dp(50)
            )
        )

        content.add_widget(
            self.make_label("برنامه امروز شما", 19)
        )

        content.add_widget(
            self.make_label(
                "یادآوری داروهایت را مدیریت کن",
                12, GRAY
            )
        )

        reminder = Card(
            orientation="vertical",
            bg_color=NAVY,
            size_hint_y=None,
            height=dp(125)
        )

        reminder.add_widget(
            self.make_label("یادآوری بعدی", 13, WHITE)
        )

        reminder.add_widget(
            self.make_label(
                "برنامه مصرف داروهایت",
                18, WHITE
            )
        )

        reminder.add_widget(
            self.make_label(
                "داروهایت را ثبت کن تا برنامه مصرفشان را مدیریت کنی.",
                11, (0.85, 0.88, 0.96, 1)
            )
        )

        content.add_widget(reminder)

        content.add_widget(
            self.make_label("داروهای من", 18)
        )

        self.medicine_list = BoxLayout(
            orientation="vertical",
            spacing=dp(8),
            size_hint_y=None
        )

        self.medicine_list.bind(
            minimum_height=self.medicine_list.setter("height")
        )

        content.add_widget(self.medicine_list)

        content.add_widget(
            self.make_button(
                "+ افزودن داروی جدید",
                self.open_add_form,
                BLUE,
                dp(52)
            )
        )

        self.refresh_medicines()
      # فرم افزودن و ویرایش دارو

    def build_add_form(self):
        root, content = self.make_scroll_page(self.add_screen)

        self.form_title = self.make_label(
            "افزودن داروی جدید 💊",
            21, NAVY, dp(55)
        )

        content.add_widget(self.form_title)

        content.add_widget(
            self.make_label("نام دارو", 14)
        )

        self.name_input = self.make_input(
            "مثلاً: استامینوفن"
        )

        content.add_widget(self.name_input)

        content.add_widget(
            self.make_label("مقدار یا دوز مصرف", 14)
        )

        self.dose_input = self.make_input(
            "مثلاً: یک عدد یا ۵۰۰ میلی‌گرم"
        )

        content.add_widget(self.dose_input)

        content.add_widget(
            self.make_label("توضیحات", 14)
        )

        self.notes_input = self.make_input(
            "توضیحات دلخواه درباره دارو",
            dp(110),
            True
        )

        content.add_widget(self.notes_input)

        self.save_button = self.make_button(
            "ذخیره دارو",
            self.save_medicine,
            BLUE,
            dp(52)
        )

        content.add_widget(self.save_button)

        content.add_widget(
            self.make_button(
                "بازگشت به داشبورد",
                self.back_to_dashboard,
                NAVY
            )
        )

    def clear_form(self):
        self.name_input.text = ""
        self.dose_input.text = ""
        self.notes_input.text = ""

    def open_add_form(self, *args):
        self.editing_medicine_id = None

        self.clear_form()

        self.form_title.text = rtl(
            "افزودن داروی جدید 💊"
        )

        self.save_button.text = rtl(
            "ذخیره دارو"
        )

        self.manager.current = "add_medicine"

    def edit_medicine(self, medicine_id):
        medicine = next(
            (
                item for item in self.medicines
                if item["id"] == medicine_id
            ),
            None
        )

        if medicine is None:
            return

        self.editing_medicine_id = medicine_id

        self.name_input.text = medicine["name"] or ""
        self.dose_input.text = medicine["dose"] or ""
        self.notes_input.text = medicine["notes"] or ""

        self.form_title.text = rtl(
            "ویرایش اطلاعات دارو ✏️"
        )

        self.save_button.text = rtl(
            "ذخیره تغییرات"
        )

        self.manager.current = "add_medicine"

    def save_medicine(self, *args):
        name = self.name_input.text.strip()
        dose = self.dose_input.text.strip()
        notes = self.notes_input.text.strip()

        if not name:
            self.name_input.hint_text = rtl(
                "لطفاً نام دارو را وارد کن"
            )
            return

        try:
            if self.editing_medicine_id is not None:
                update_medicine(
                    self.editing_medicine_id,
                    name,
                    dose,
                    notes
                )
            else:
                add_medicine(name, dose, notes)

            self.clear_form()
            self.editing_medicine_id = None

            self.refresh_medicines()
            self.manager.current = "dashboard"

        except Exception as error:
            print("خطا در ذخیره اطلاعات دارو:", error)

    # فرم زمان‌بندی دارو

    def build_schedule_form(self):
        root = BoxLayout(
            orientation="vertical",
            padding=dp(18),
            spacing=dp(12)
        )

        root.add_widget(
            self.make_label(
                "تنظیم زمان مصرف ⏰",
                21, NAVY, dp(55)
            )
        )

        self.schedule_medicine_label = self.make_label(
            "داروی انتخاب‌شده",
            15, PURPLE
        )

        root.add_widget(self.schedule_medicine_label)

        root.add_widget(
            self.make_label(
                "ساعت مصرف را وارد کن؛ مثل 16 یا 16:30",
                14, GRAY
            )
        )

        self.schedule_time_input = self.make_input(
            "مثلاً 08:30"
        )

        root.add_widget(self.schedule_time_input)

        root.add_widget(
            self.make_button(
                "ثبت ساعت مصرف",
                self.save_schedule,
                GREEN,
                dp(52)
            )
        )

        root.add_widget(
            self.make_button(
                "بازگشت به داشبورد",
                self.back_to_dashboard,
                NAVY
            )
        )

        self.schedule_screen.add_widget(root)

    def open_schedule_form(self, medicine_id):
        medicine = next(
            (
                item for item in self.medicines
                if item["id"] == medicine_id
            ),
            None
        )

        if medicine is None:
            return

        self.selected_medicine_id = medicine_id

        self.schedule_medicine_label.text = rtl(
            "داروی انتخاب‌شده: " + medicine["name"]
        )

        self.schedule_time_input.text = ""

        self.manager.current = "schedule"

    def save_schedule(self, *args):
        if self.selected_medicine_id is None:
            return

        time_value = self.schedule_time_input.text.strip()

        if time_value.isdigit():
            time_value += ":00"

        try:
            datetime.strptime(time_value, "%H:%M")

        except ValueError:
            self.schedule_time_input.hint_text = rtl(
                "ساعت معتبر وارد کن؛ مثلاً 16 یا 16:30"
            )
            return

        try:
            schedules = get_medicine_schedules(
                self.selected_medicine_id
            )

            if any(
                item["time"] == time_value
                for item in schedules
            ):
                print("این ساعت قبلاً ثبت شده است.")
                return

            add_medicine_schedule(
                self.selected_medicine_id,
                time_value
            )

            self.schedule_time_input.text = ""

            self.refresh_medicines()
            self.manager.current = "dashboard"

        except Exception as error:
            print("خطا در ثبت ساعت:", error)

    def remove_schedule(self, schedule_id):
        try:
            delete_medicine_schedule(schedule_id)
            self.refresh_medicines()

        except Exception as error:
            print("خطا در حذف ساعت:", error)

    # فهرست داروها

    def refresh_medicines(self):
        self.medicines = get_all_medicines()

        self.medicine_list.clear_widgets()

        if not self.medicines:
            self.medicine_list.add_widget(
                self.make_label(
                    "هنوز دارویی اضافه نکرده‌ای",
                    13, GRAY, dp(55), "center"
                )
            )
            return

        for medicine in self.medicines:
            schedules = get_medicine_schedules(
                medicine["id"]
            )

            card_height = dp(
                190 + len(schedules) * 38
            )

            card = Card(
                orientation="vertical",
                size_hint_y=None,
                height=card_height
            )

            card.add_widget(
                self.make_label(
                    "💊 " + medicine["name"],
                    16, NAVY
                )
            )

            card.add_widget(
                self.make_label(
                    medicine["dose"] or "دوز ثبت نشده",
                    12, GRAY
                )
            )

            if schedules:
                card.add_widget(
                    self.make_label(
                        "ساعت‌های مصرف:",
                        12, PURPLE
                    )
                )

                for schedule in schedules:
                    row = BoxLayout(
                        orientation="horizontal",
                        size_hint_y=None,
                        height=dp(30),
                        spacing=dp(6)
                    )

                    row.add_widget(
                        self.make_label(
                            "⏰ " + schedule["time"],
                            12, NAVY, dp(30)
                        )
                    )

                    row.add_widget(
                        self.make_button(
                            "حذف",
                            lambda button, sid=schedule["id"]:
                                self.remove_schedule(sid),
                            RED,
                            dp(30)
                        )
                    )

                    card.add_widget(row)

            else:
                card.add_widget(
                    self.make_label(
                        "هنوز ساعتی ثبت نشده است.",
                        11, GRAY
                    )
                )

            buttons = BoxLayout(
                orientation="horizontal",
                size_hint_y=None,
                height=dp(38),
                spacing=dp(5)
            )

            buttons.add_widget(
                self.make_button(
                    "تنظیم ساعت",
                    lambda button, mid=medicine["id"]:
                        self.open_schedule_form(mid),
                    GREEN,
                    dp(38)
                )
            )

            buttons.add_widget(
                self.make_button(
                    "آزمایش پازل",
                    lambda button, mid=medicine["id"]:
                        self.start_puzzle(mid),
                    PURPLE,
                    dp(38)
                )
            )

            buttons.add_widget(
                self.make_button(
                    "ویرایش",
                    lambda button, mid=medicine["id"]:
                        self.edit_medicine(mid),
                    BLUE,
                    dp(38)
                )
            )

            buttons.add_widget(
                self.make_button(
                    "حذف",
                    lambda button, mid=medicine["id"], name=medicine["name"]:
                    self.remove_medicine(mid, name),
                    RED,
                    dp(38)
                )
            )

            card.add_widget(buttons)

            self.medicine_list.add_widget(card)

    
    def remove_medicine(self, medicine_id, medicine_name):
        content = BoxLayout(
            orientation="vertical",
            spacing=dp(15),
            padding=dp(20)
        )

        content.add_widget(
            self.make_label(
                "آیا از حذف این دارو مطمئن هستید؟",
                14,
                WHITE
            )
        )

        buttons = BoxLayout(
            orientation="horizontal",
            spacing=dp(10),
            size_hint_y=None,
            height=dp(45)
        )

        popup = Popup(
    title=rtl(f"حذف داروی {medicine_name}"),
    title_font=str(FONT_PATH),
    title_color=WHITE,
    content=content,
    size_hint=(0.85, None),
    height=dp(190),
    auto_dismiss=False
)

        buttons.add_widget(
            self.make_button(
                "انصراف",
                lambda button: popup.dismiss(),
                GRAY,
                dp(45)
            )
        )

        def confirm_delete(button):
            try:
                delete_medicine(medicine_id)
                self.refresh_medicines()
                popup.dismiss()
            except Exception as error:
                print("خطا در حذف دارو:", error)

        buttons.add_widget(
            self.make_button(
                "بله، حذف کن",
                confirm_delete,
                RED,
                dp(45)
            )
        )

        content.add_widget(buttons)
        popup.open()

    # -------------------- پازل --------------------

    def build_puzzle_screen(self):
        root = BoxLayout(
            orientation="vertical",
            padding=dp(20),
            spacing=dp(12)
        )

        root.add_widget(
            self.make_label(
                "زمان مصرف دارو فرا رسیده! ⏰",
                20, NAVY, dp(60)
            )
        )

        self.puzzle_medicine_label = self.make_label(
            "دارو", 15, PURPLE, dp(40)
        )

        root.add_widget(self.puzzle_medicine_label)

        root.add_widget(
            self.make_label(
                "برای فعال شدن تأیید مصرف، معما را حل کن.",
                13, GRAY, dp(50)
            )
        )

        puzzle_card = Card(
            orientation="vertical",
            bg_color=WHITE,
            size_hint_y=None,
            height=dp(210)
        )

        puzzle_card.add_widget(
            self.make_label("🧩 چالش ریاضی", 18, PURPLE)
        )

        self.puzzle_question = self.make_label(
            "12 + 8 = ؟", 30, NAVY, dp(65), "center"
        )

        puzzle_card.add_widget(self.puzzle_question)

        self.puzzle_answer = self.make_input(
            "پاسخ را وارد کن"
        )

        self.puzzle_answer.input_filter = "int"

        puzzle_card.add_widget(self.puzzle_answer)

        root.add_widget(puzzle_card)

        self.puzzle_result = self.make_label(
            "", 13, GREEN, dp(45)
        )

        root.add_widget(self.puzzle_result)

        self.puzzle_check_button = self.make_button(
            "بررسی پاسخ",
            self.check_puzzle_answer,
            PURPLE,
            dp(52)
        )

        root.add_widget(self.puzzle_check_button)

        self.taken_button = self.make_button(
            "دارو را مصرف کردم",
            self.confirm_medicine_taken,
            GREEN,
            dp(55)
        )

        self.taken_button.disabled = True

        root.add_widget(self.taken_button)

        root.add_widget(
            self.make_button(
                "بازگشت به داشبورد",
                self.back_to_dashboard,
                NAVY
            )
        )

        self.puzzle_screen.add_widget(root)
    def start_scheduled_puzzle(self, medicine_id, log_id):
        medicine = next(
            (
                item for item in self.medicines
                if item["id"] == medicine_id
            ),
            None
        )

        if medicine is None:
            return

        self.selected_medicine_id = medicine_id
        self.current_intake_log_id = log_id

        self.puzzle_medicine_label.text = rtl(
            "زمان مصرف دارو رسیده است: " + medicine["name"]
        )

        self.puzzle_answer.text = ""
        self.puzzle_result.text = ""

        self.taken_button.disabled = True
        self.puzzle_check_button.disabled = False

        self.generate_puzzle()
        self.manager.current = "puzzle"

    def start_puzzle(self, medicine_id):
        medicine = next(
            (
                item for item in self.medicines
                if item["id"] == medicine_id
            ),
            None
        )

        if medicine is None:
            return

        now = datetime.now()

        try:
            log_id = add_intake_log(
                medicine_id,
                None,
                now.strftime("%Y-%m-%d"),
                now.strftime("%H:%M")
            )

        except Exception as error:
            print("خطا در ایجاد نوبت آزمایشی:", error)
            return

        self.selected_medicine_id = medicine_id
        self.current_intake_log_id = log_id

        self.puzzle_medicine_label.text = rtl(
            "داروی انتخاب‌شده: " + medicine["name"]
        )

        self.puzzle_answer.text = ""
        self.puzzle_result.text = ""

        self.taken_button.disabled = True
        self.puzzle_check_button.disabled = False

        self.generate_puzzle()

        self.manager.current = "puzzle"

    def generate_puzzle(self):
        first = random.randint(5, 30)
        second = random.randint(1, 20)

        operation = random.choice(["+", "-"])

        if operation == "-" and second > first:
            first, second = second, first

        self.correct_answer = (
            first + second if operation == "+"
            else first - second
        )

        self.puzzle_question.text = rtl(
            f"{first} {operation} {second} = ؟"
        )

    def check_puzzle_answer(self, *args):
        if self.current_intake_log_id is None:
            return

        answer_text = self.puzzle_answer.text.strip()

        if not answer_text:
            self.puzzle_result.text = rtl(
                "ابتدا پاسخ را وارد کن."
            )
            return

        try:
            answer = int(answer_text)

        except ValueError:
            self.puzzle_result.text = rtl(
                "لطفاً فقط عدد وارد کن."
            )
            return

        if answer != self.correct_answer:
            self.puzzle_result.color = RED

            self.puzzle_result.text = rtl(
                "پاسخ اشتباه است؛ دوباره تلاش کن."
            )

            self.puzzle_answer.text = ""
            return

        try:
            success = mark_puzzle_solved(
                self.current_intake_log_id,
                datetime.now().isoformat(timespec="seconds")
            )

            if not success:
                self.puzzle_result.color = RED
                self.puzzle_result.text = rtl(
                    "ثبت حل پازل انجام نشد. دوباره تلاش کن."
                )
                return

        except Exception as error:
            print("خطا در ثبت حل پازل:", error)
            return

        self.puzzle_result.color = GREEN

        self.puzzle_result.text = rtl(
            "آفرین! پازل حل شد. حالا مصرف دارو را تأیید کن."
        )

        self.puzzle_check_button.disabled = True
        self.taken_button.disabled = False

    def confirm_medicine_taken(self, *args):
        if self.current_intake_log_id is None:
            return

        if self.taken_button.disabled:
            return

        try:
            success = mark_medicine_taken(
                self.current_intake_log_id,
                datetime.now().isoformat(timespec="seconds")
            )

            if not success:
                self.puzzle_result.color = RED
                self.puzzle_result.text = rtl(
                    "امکان ثبت مصرف وجود ندارد. ابتدا پازل را حل کن."
                )
                return

            self.puzzle_result.color = GREEN

            self.puzzle_result.text = rtl(
                "مصرف دارو در تاریخچه ثبت شد. مراقب خودت باش!"
            )
         
            self.taken_button.disabled = True
            self.current_intake_log_id = None

        except Exception as error:
            print("خطا در ثبت مصرف دارو:", error)
    # -------------------- تاریخچه --------------------

    def build_history_screen(self):
        root, content = self.make_scroll_page(
            self.history_screen
        )

        content.add_widget(
            self.make_label(
                "تاریخچه مصرف داروها",
                21, NAVY, dp(55)
            )
        )

        self.history_list = BoxLayout(
            orientation="vertical",
            spacing=dp(8),
            size_hint_y=None
        )

        self.history_list.bind(
            minimum_height=self.history_list.setter("height")
        )

        content.add_widget(self.history_list)

    def open_history(self, *args):
        self.refresh_history()
        self.manager.current = "history"

    def refresh_history(self):
        self.history_list.clear_widgets()

        try:
            logs = get_all_intake_logs()

        except Exception as error:
            print("خطا در دریافت تاریخچه:", error)
            return

        if not logs:
            self.history_list.add_widget(
                self.make_label(
                    "هنوز سابقه‌ای ثبت نشده است.",
                    13, GRAY, dp(55), "center"
                )
            )
            return

        for log in logs:

            if log["taken"]:
                status = "مصرف تأیید شده"

            elif log["puzzle_solved"]:
                status = "پازل حل شده؛ مصرف تأیید نشده"

            else:
                status = "در انتظار حل پازل"

            card = Card(
                orientation="vertical",
                size_hint_y=None,
                height=dp(115)
            )

            card.add_widget(
                self.make_label(
                    "💊 " + log["medicine_name"],
                    15, NAVY
                )
            )

            card.add_widget(
                self.make_label(
                    f'{log["scheduled_date"]} - {log["scheduled_time"]}',
                    12, GRAY
                )
            )

            card.add_widget(
                self.make_label(
                    status,
                    12, PURPLE
                )
            )

            self.history_list.add_widget(card)

    # -------------------- تنظیمات --------------------

    def build_settings_screen(self):
        root, content = self.make_scroll_page(
            self.settings_screen
        )

        content.add_widget(
            self.make_label(
                "تنظیمات برنامه",
                21, NAVY, dp(55)
            )
        )

        content.add_widget(
            self.make_label(
                "بخش تنظیمات در نسخه بعدی تکمیل می‌شود.",
                14, GRAY, dp(60)
            )
        )

        content.add_widget(
            self.make_label(
                "در این بخش می‌توانیم صدا، نوع پازل و تنظیمات یادآوری را اضافه کنیم.",
                13, NAVY, dp(80)
            )
        )

    # -------------------- بازگشت به داشبورد --------------------

    def back_to_dashboard(self, *args):
        self.editing_medicine_id = None

        self.manager.current = "dashboard"

        self.refresh_medicines()

    def check_medicine_reminders(self, *args):
        now = datetime.now()

        current_date = now.strftime("%Y-%m-%d")
        current_time = now.strftime("%H:%M")
        current_minute = now.strftime("%Y-%m-%d %H:%M")

        # جلوگیری از بررسی چندباره در یک دقیقه
        if self.last_reminder_minute == current_minute:
            return

        self.last_reminder_minute = current_minute

        try:
            medicines = get_all_medicines()

            for medicine in medicines:
                schedules = get_medicine_schedules(
                    medicine["id"]
                )

                for schedule in schedules:

    # بررسی روزهای انتخاب‌شده برای مصرف دارو
                        # بررسی روزهای انتخاب‌شده برای مصرف دارو
                    allowed_weekdays = [
                        int(day)
                        for day in schedule["weekdays"].split(",")
                    ]

                    iran_weekday = (now.weekday() + 2) % 7

                    if iran_weekday not in allowed_weekdays:
                        continue

                    if schedule["time"] != current_time:
                        continue
                    if intake_log_exists(
                        schedule["id"],
                        current_date,
                        current_time
                    ):
                        continue

                    log_id = add_intake_log(
                        medicine["id"],
                        schedule["id"],
                        current_date,
                        current_time
                    )

                    self.start_scheduled_puzzle(
                        medicine["id"],
                        log_id
                    )

        except Exception as error:
            print("خطا در بررسی یادآورها:", error)
# -------------------- اجرای برنامه --------------------

if __name__ == "__main__":
    MedPuzzleApp().run()