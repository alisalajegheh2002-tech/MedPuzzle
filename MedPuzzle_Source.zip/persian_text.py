
from pathlib import Path

import arabic_reshaper
from bidi.algorithm import get_display


# مسیر فونت فارسی برنامه
FONT_PATH = (
    Path(__file__).resolve().parent.parent
    / "assets"
    / "fonts"
    / "Vazirmatn.ttf"
)


def rtl(text):
    """
    آماده‌سازی متن فارسی برای نمایش صحیح در Kivy.
    """
    reshaped_text = arabic_reshaper.reshape(str(text))
    return get_display(reshaped_text)
