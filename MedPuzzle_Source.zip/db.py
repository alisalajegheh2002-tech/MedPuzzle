
import sqlite3
from pathlib import Path

DATABASE_PATH = Path(__file__).resolve().parent / "medpuzzle.db"


def get_connection():
    connection = sqlite3.connect(DATABASE_PATH)
    connection.row_factory = sqlite3.Row
    connection.execute("PRAGMA foreign_keys = ON")
    return connection


def initialize_database():
    with get_connection() as connection:
        connection.execute("""
            CREATE TABLE IF NOT EXISTS medicines (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                dose TEXT,
                notes TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)

        connection.execute("""
            CREATE TABLE IF NOT EXISTS medicine_schedules (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                medicine_id INTEGER NOT NULL,
                time TEXT NOT NULL,
                weekdays TEXT DEFAULT '0,1,2,3,4,5,6',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (medicine_id)
                    REFERENCES medicines(id)
            )
        """)

        connection.execute("""
            CREATE TABLE IF NOT EXISTS medicine_intake_logs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                medicine_id INTEGER NOT NULL,
                schedule_id INTEGER,
                scheduled_date TEXT NOT NULL,
                scheduled_time TEXT NOT NULL,
                puzzle_solved INTEGER DEFAULT 0,
                puzzle_solved_at TEXT,
                taken INTEGER DEFAULT 0,
                taken_at TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (medicine_id)
                    REFERENCES medicines(id)
            )
        """)

        # جلوگیری از ثبت چندباره یک نوبت زمان‌بندی‌شده
        connection.execute("""
            CREATE UNIQUE INDEX IF NOT EXISTS
            idx_unique_scheduled_intake
            ON medicine_intake_logs (
                schedule_id,
                scheduled_date,
                scheduled_time
            )
            WHERE schedule_id IS NOT NULL
        """)


def add_medicine(name, dose="", notes=""):
    with get_connection() as connection:
        cursor = connection.execute(
            """
            INSERT INTO medicines (name, dose, notes)
            VALUES (?, ?, ?)
            """,
            (name, dose, notes)
        )
        return cursor.lastrowid


def get_all_medicines():
    with get_connection() as connection:
        return connection.execute(
            "SELECT * FROM medicines ORDER BY id DESC"
        ).fetchall()


def delete_medicine(medicine_id):
    with get_connection() as connection:
        connection.execute(
            "DELETE FROM medicine_schedules WHERE medicine_id = ?",
            (medicine_id,)
        )

        connection.execute(
            "DELETE FROM medicine_intake_logs WHERE medicine_id = ?",
            (medicine_id,)
        )

        connection.execute(
            "DELETE FROM medicines WHERE id = ?",
            (medicine_id,)
        )


def update_medicine(medicine_id, name, dose="", notes=""):
    with get_connection() as connection:
        connection.execute(
            """
            UPDATE medicines
            SET name = ?, dose = ?, notes = ?
            WHERE id = ?
            """,
            (name, dose, notes, medicine_id)
        )


def add_medicine_schedule(
    medicine_id,
    time,
    weekdays="0,1,2,3,4,5,6"
):
    # استانداردسازی ساعت
    try:
        hour, minute = map(int, time.strip().split(":"))

        if not (0 <= hour <= 23 and 0 <= minute <= 59):
            raise ValueError

        time = f"{hour:02d}:{minute:02d}"

    except (ValueError, AttributeError):
        raise ValueError(
            "فرمت ساعت باید مانند 09:30 باشد."
        )

    with get_connection() as connection:
        cursor = connection.execute(
            """
            INSERT INTO medicine_schedules (
                medicine_id, time, weekdays
            )
            VALUES (?, ?, ?)
            """,
            (medicine_id, time, weekdays)
        )

        return cursor.lastrowid


def get_medicine_schedules(medicine_id):
    with get_connection() as connection:
        return connection.execute(
            """
            SELECT *
            FROM medicine_schedules
            WHERE medicine_id = ?
            ORDER BY time
            """,
            (medicine_id,)
        ).fetchall()


def delete_medicine_schedule(schedule_id):
    with get_connection() as connection:
        connection.execute(
            "DELETE FROM medicine_schedules WHERE id = ?",
            (schedule_id,)
        )


def add_intake_log(
    medicine_id,
    schedule_id,
    scheduled_date,
    scheduled_time
):
    with get_connection() as connection:
        cursor = connection.execute(
            """
            INSERT INTO medicine_intake_logs (
                medicine_id,
                schedule_id,
                scheduled_date,
                scheduled_time
            )
            VALUES (?, ?, ?, ?)
            """,
            (
                medicine_id,
                schedule_id,
                scheduled_date,
                scheduled_time
            )
        )

        return cursor.lastrowid


def mark_puzzle_solved(log_id, solved_at):
    with get_connection() as connection:
        cursor = connection.execute(
            """
            UPDATE medicine_intake_logs
            SET puzzle_solved = 1,
                puzzle_solved_at = ?
            WHERE id = ?
              AND puzzle_solved = 0
              AND taken = 0
            """,
            (solved_at, log_id)
        )

        return cursor.rowcount == 1


def mark_medicine_taken(log_id, taken_at):
    with get_connection() as connection:
        cursor = connection.execute(
            """
            UPDATE medicine_intake_logs
            SET taken = 1,
                taken_at = ?
            WHERE id = ?
              AND puzzle_solved = 1
              AND taken = 0
            """,
            (taken_at, log_id)
        )

        return cursor.rowcount == 1


def get_medicine_intake_logs(medicine_id):
    with get_connection() as connection:
        return connection.execute(
            """
            SELECT *
            FROM medicine_intake_logs
            WHERE medicine_id = ?
            ORDER BY scheduled_date DESC, scheduled_time DESC
            """,
            (medicine_id,)
        ).fetchall()


def get_all_intake_logs():
    with get_connection() as connection:
        return connection.execute(
            """
            SELECT
                medicine_intake_logs.*,
                medicines.name AS medicine_name
            FROM medicine_intake_logs
            INNER JOIN medicines
                ON medicines.id = medicine_intake_logs.medicine_id
            ORDER BY
                scheduled_date DESC,
                scheduled_time DESC
            """
        ).fetchall()


def intake_log_exists(schedule_id, scheduled_date, scheduled_time):
    with get_connection() as connection:
        result = connection.execute(
            """
            SELECT id
            FROM medicine_intake_logs
            WHERE schedule_id = ?
              AND scheduled_date = ?
              AND scheduled_time = ?
            LIMIT 1
            """,
            (schedule_id, scheduled_date, scheduled_time)
        ).fetchone()

        return result is not None
